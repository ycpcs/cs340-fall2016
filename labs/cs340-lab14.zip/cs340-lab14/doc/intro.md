# Introduction to clojure-review

TODO: write [great documentation](http://jacobian.org/writing/great-documentation/what-to-write/)
