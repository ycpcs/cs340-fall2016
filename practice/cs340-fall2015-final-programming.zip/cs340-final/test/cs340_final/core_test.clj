(ns cs340-final.core-test
  (:require [clojure.test :refer :all]
            [cs340-final.core :refer :all]))

;(deftest a-test
;  (testing "FIXME, I fail."
;    (is (= 0 1))))


;   (frobnicate even? 3) => [3]
;   (frobnicate even? 4) => [4 4]
;   (frobnicate (fn [s] (= (count s) 3)) [:a :b]) =>
;     [[:a :b]]
;   (frobnicate (fn [s] (= (count s) 3)) [:a :b :c]) =>
;     [[:a :b :c] [:a :b :c]]
;   (frobnicate empty? []) => [[] []]
;   (frobnicate empty? [:a :b :c]) => [[:a :b :c]]
(deftest frobnicate-test
  (testing "frobnicate"
    (is (= [3] (frobnicate even? 3)))
    (is (= [4 4] (frobnicate even? 4)))
    (is (= [[:a :b]] (frobnicate (fn [s] (= (count s) 3)) [:a :b])))
    (is (= [[:a :b :c] [:a :b :c]] (frobnicate (fn [s] (= (count s) 3)) [:a :b :c])))
    (is (= [[] []] (frobnicate empty? [])))
    (is (= [[:a :b :c]] (frobnicate empty? [:a :b :c])))
    ))

;   ((make-doubler 0) [:a :b :c]) => [:a :b :c]
;   ((make-doubler 1) [:a :b :c]) => [:a :a :b :b :c :c]
;   ((make-doubler 2) [:a :b :c]) => [:a :a :a :a :b :b :b :b :c :c :c :c]
(deftest make-doubler-test
  (testing "make-doubler"
    (is (= [:a :b :c] ((make-doubler 0) [:a :b :c])))
    (is (= [:a :a :b :b :c :c] ((make-doubler 1) [:a :b :c])))
    (is (= [:a :a :a :a :b :b :b :b :c :c :c :c] ((make-doubler 2) [:a :b :c])))
    ))

;  (combine-pairs + [1 2 3 4 5 6 7 8]) => [3 7 11 15]
;  (combine-pairs + [1 2 3 4 5 6 7]) => [3 7 11 7]
;  (combine-pairs * [3 6 2 5 1 8]) => [18 10 8]
;  (combine-pairs str ["hello" "I" "am" "pleased" "to" "meet" "you"]) =>
;    ["helloI" "ampleased" "tomeet" "you"]
(deftest combine-pairs-test
  (testing "combine-pairs"
    (is (= [3 7 11 15] (combine-pairs + [1 2 3 4 5 6 7 8])))
    (is (= [3 7 11 7] (combine-pairs + [1 2 3 4 5 6 7])))
    (is (= [18 10 8] (combine-pairs * [3 6 2 5 1 8])))
    (is (= ["helloI" "ampleased" "tomeet" "you"]
           (combine-pairs str ["hello" "I" "am" "pleased" "to" "meet" "you"])))
    ))

(def DELTA 0.00001)

(defn approx-= [v1 v2]
  (< (Math/abs (- v1 v2)) DELTA))

;   (weighted-average [100 90] [0.5 0.5]) => 95.0
;   (weighted-average [100 90] [0.6 0.4]) => 96.0
;   (weighted-average [100 90] [0.4 0.6]) => 94.0
;   (weighted-average [100 90] [0.1 0.15]) => 94.0
(deftest weighted-average-test
  (testing "weighted-average"
    (is (approx-= 95.0  (weighted-average [100 90] [0.5 0.5])))
    (is (approx-= 96.0 (weighted-average [100 90] [0.6 0.4])))
    (is (approx-= 94.0 (weighted-average [100 90] [0.4 0.6])))
    (is (approx-= 94.0 (weighted-average [100 90] [0.1 0.15])))
    ))
