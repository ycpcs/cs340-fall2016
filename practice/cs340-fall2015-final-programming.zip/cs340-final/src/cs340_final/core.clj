(ns cs340-final.core)

; Question 1. [20 points]
;
; The frobnicate function takes two parameters, a predicate function p and a
; value v.  If the result of applying p to v is true, then
; frobnicate returns a vector with two copies of v.  Otherwise,
; it returns a vector with a single copy of v.
;
; Examples:
;   (frobnicate even? 3) => [3]
;   (frobnicate even? 4) => [4 4]
;   (frobnicate (fn [s] (= (count s) 3)) [:a :b]) =>
;     [[:a :b]]
;   (frobnicate (fn [s] (= (count s) 3)) [:a :b :c]) =>
;     [[:a :b :c] [:a :b :c]]
;   (frobnicate empty? []) => [[] []]
;   (frobnicate empty? [:a :b :c]) => [[:a :b :c]]
;
(defn frobnicate [p v]
  "OHAI!")

; This function will be useful in the definition of
; the make-doubler function for Question 2.
(defn double-seq [a-seq]
  (vec (flatten (map (fn [x] [x x]) a-seq))))

; Question 2. [10 points]
;
; The make-doubler function takes a non-negative integer n,
; and returns a function taking one parameter.  When the
; returned function is applied to a sequence it applies
; the double-seq function (see above) to the sequence
; n times.  The double-seq function doubles (creates two copies
; of) each element in the sequence to which it is applied.
; 
; Requirement: The function returned by make-doubler must
; be tail-recursive.
;
; Examples:
;   ((make-doubler 0) [:a :b :c]) => [:a :b :c]
;   ((make-doubler 1) [:a :b :c]) => [:a :a :b :b :c :c]
;   ((make-doubler 2) [:a :b :c]) => [:a :a :a :a :b :b :b :b :c :c :c :c]
;
; Hints:
; - Make sure that make-doubler returns a function taking a single
;   parameter!
; 
(defn make-doubler [n]
  "I CAN HAZ HIGHER-ORDER FUNCTION?")


; Question 3. [15 points]
; 
; The combine-pairs function takes two parameters, a function (f)
; taking two parameters, and a sequence (a-seq).
; The result of combine-pairs is a sequence in
; which each element is the result of applying f to
; a pair of values in a-seq.  As a special case,
; if a-seq has an odd number of values, the last
; value of a-seq should be added to the result
; sequence (without having f applied to it).
;
; Requirement: Your implementation must be tail-recursive,
; or must call one (or more) of the built-in tail-recursive
; sequence processing functions (such as map or mapv).
;
; Examples:
;  (combine-pairs + [1 2 3 4 5 6 7 8]) => [3 7 11 15]
;  (combine-pairs + [1 2 3 4 5 6 7]) => [3 7 11 7]
;  (combine-pairs * [3 6 2 5 1 8]) => [18 10 8]
;  (combine-pairs str ["hello" "I" "am" "pleased" "to" "meet" "you"]) =>
;    ["helloI" "ampleased" "tomeet" "you"]
;
(defn combine-pairs [f a-seq]
  "OHAI!")


; Question 4. [5 points]
; 
; The weighted-average function takes two sequences,
; vals and coeffs, as parameters.  You can assume
; vals and coeffs consist entirely of numbers, and
; that each sequence has the same number of elements.
;
; The weighted-average function returns a single numeric
; result as follows:
;
; (1) multiply each member of vals to the corresponding member of coeffs
; (2) compute the sum of the products found in step (1)
; (3) compute the sum of the members of coeffs
; (4) the overall result is the value computed in step (2) divided by
;     the value computed in step (3)
;
; Examples:
;   (weighted-average [100 90] [0.5 0.5]) => 95.0
;   (weighted-average [100 90] [0.6 0.4]) => 96.0
;   (weighted-average [100 90] [0.4 0.6]) => 94.0
;   (weighted-average [100 90] [0.1 0.15]) => 94.0
;
; Hints:
; - This is really easy if you use map and reduce (but
;   any way you want to solve this is fine)
;
(defn weighted-average [vals coeffs]
  "KTHXBYE!")
